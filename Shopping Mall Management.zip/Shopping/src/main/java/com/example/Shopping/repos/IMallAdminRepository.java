package com.example.Shopping.repos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Shopping.model.MallAdmin;

public interface IMallAdminRepository extends JpaRepository<MallAdmin, Integer> {

}
